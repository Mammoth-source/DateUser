import datetime
now = datetime.datetime.now()

def PrintHi():
    print("Welcome User")
def Friendly(datetime):
    print(now.strftime("%Y-%m-%d %H:%M:"))
def DayToday():
    print(now.strftime("%d"))
def MonthToday():
    print(now.strftime("%M"))
def Unfriendly(datetime):
    print(datetime.datetime.now)